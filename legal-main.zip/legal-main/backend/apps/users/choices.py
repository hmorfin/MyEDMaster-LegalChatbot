PROFESSION_CHOICES = [
    "Legal Professional",
    "Healthcare Professional",
    "Education Professional",
    "Government Employee",
    "Military",
    "IT Professional",
    "Finance Professional",
    "Business Owner",
    "Student",
    "Retired",
    "Other",
]

EMPLOYMENT_TYPE_CHOICES = [
    "Full-Time",
    "Part-Time",
    "Self-Employed",
    "Contract",
    "Temporary",
    "Student",
    "Unemployed",
    "Retired",
]

VETERAN_STATUS_CHOICES = [
    "Veteran",
    "Non-Veteran",
    "Active Duty",
    "Prefer Not to Say",
]

DISABILITY_STATUS_CHOICES = [
    "None",
    "Yes",
    "Prefer Not to Say",
]

MARITAL_STATUS_CHOICES = [
    "Single",
    "Married",
    "Divorced",
    "Prefer Not to Say",
]

INCOME_BRACKET_CHOICES = [
    "Below $25,000",
    "$25,000 - $34,999",
    "$35,000 - $49,999",
    "$50,000 - $74,999",
    "$75,000 - $99,999",
    "$100,000 - $149,999",
    "$150,000+",
]
