# #This script tests the pdf extraction logic. Prints the extracted text as output
# from .extractor import extractor

# text = extractor.extract_from_s3(document_id="Sample_Residential_Rental_Agreement_John_Larry", chat_id="chat-id-1")
# print(text)
